#!/bin/sh

# Change the following address to your address

ADDRESS=rJdg3SfdwrFo9ABrkqM6J6MF18kQSUieBc

USERNAME=$ADDRESS.vultr
POOL=stratum.ravenminer.com:13838
SCHEME=raven


./bminer -uri $SCHEME://$USERNAME@$POOL -api 127.0.0.1:1880
